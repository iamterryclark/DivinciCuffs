//
//  main.m
//  myoooo
//
//  Created by Terry Clark on 05/03/2018.
//  Copyright © 2018 Terry Clark. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
