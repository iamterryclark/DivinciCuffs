//
//  ViewController.m
//  myoooo
//
//  Created by Terry Clark on 05/03/2018.
//  Copyright © 2018 Terry Clark. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
